#!/bin/bash

# launches python redis launcher
export LANG=C
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
cd $DIR

if [ -x /opt/flussonic/bin/python3 ] ; then
  PYTHON=/opt/flussonic
else
  if [ -x "$DIR/flask/bin/python3" ]; then
    PYTHON="$DIR/flask"
  else
    PYTHON=/usr
  fi
fi

exec "$PYTHON/bin/python3" -m launcher run_redis "$1" "${@:2}" 2>&1