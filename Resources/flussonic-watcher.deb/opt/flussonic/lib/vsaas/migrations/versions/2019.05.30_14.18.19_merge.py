"""merge

Revision ID: f98421fdb9c3
Revises: ('f979ef8c0f9b', '85534d45a2e2')
Create Date: 2019-05-30 14:18:19.086278

"""

# revision identifiers, used by Alembic.
revision = 'f98421fdb9c3'
down_revision = ('f979ef8c0f9b', '85534d45a2e2')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
