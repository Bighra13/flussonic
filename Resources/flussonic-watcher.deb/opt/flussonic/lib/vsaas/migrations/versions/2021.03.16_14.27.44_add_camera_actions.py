"""add_camera_actions

Revision ID: 2f5040658195
Revises: 439e3b884c6b
Create Date: 2021-03-16 14:27:44.007885

"""

# revision identifiers, used by Alembic.
revision = '2f5040658195'
down_revision = '439e3b884c6b'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402
from sqlalchemy.dialects import postgresql  # noqa: F402


def upgrade():
  op.add_column(
    'cloud_streams',
    sa.Column(
      'actions',
      postgresql.JSONB(astext_type=sa.Text()),
      server_default=sa.text("'{}'::jsonb"),
      nullable=False
    )
  )


def downgrade():
  op.drop_column('cloud_streams', 'actions')
