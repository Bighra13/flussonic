"""status.lifetime bigint

Revision ID: d7cc42042c08
Revises: e93eb144a9b6
Create Date: 2020-10-26 16:34:00.159321

"""

# revision identifiers, used by Alembic.
revision = 'd7cc42042c08'
down_revision = 'e93eb144a9b6'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    op.alter_column('stream_statuses', 'lifetime', type_=sa.BIGINT())
    op.alter_column('stream_statuses', 'dvr_range_start', type_=sa.BIGINT())
    op.alter_column('stream_statuses', 'dvr_range_end', type_=sa.BIGINT())
    op.alter_column('stream_statuses', 'dvr_bytes', type_=sa.BIGINT())
    op.execute('DROP INDEX IF EXISTS ix_events_camera_id')
    op.execute('DROP INDEX IF EXISTS ix_events_cam_id')
    op.execute('CREATE INDEX ix_events_camera_id ON events (camera_id)')


def downgrade():
    op.execute('DROP INDEX IF EXISTS ix_events_camera_id')
    pass
