"""v21.08

Revision ID: v21.08
Revises: 9e3b5aef0ccb
Create Date: 2021-08-02 14:19:13.789037

"""

# revision identifiers, used by Alembic.
revision = 'v21.08'
down_revision = '9e3b5aef0ccb'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
