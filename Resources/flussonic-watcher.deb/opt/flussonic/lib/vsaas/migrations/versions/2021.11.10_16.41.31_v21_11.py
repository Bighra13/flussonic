"""v21.11

Revision ID: v21.11
Revises: 28aa3341b901
Create Date: 2021-11-10 16:41:31.786088

"""

# revision identifiers, used by Alembic.
revision = 'v21.11'
down_revision = '28aa3341b901'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
