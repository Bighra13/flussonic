"""v19.09

Revision ID: v19.09
Revises: 2fc02761f185
Create Date: 2019-10-31 18:42:07.964244

"""

# revision identifiers, used by Alembic.
revision = 'v19.09'
down_revision = '2fc02761f185'

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
