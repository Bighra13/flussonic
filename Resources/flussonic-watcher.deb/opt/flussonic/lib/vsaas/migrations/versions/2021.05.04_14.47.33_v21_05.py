"""v21.05

Revision ID: v21.05
Revises: 593f289036c8
Create Date: 2021-05-04 14:47:33.153083

"""

# revision identifiers, used by Alembic.
revision = 'v21.05'
down_revision = '593f289036c8'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
