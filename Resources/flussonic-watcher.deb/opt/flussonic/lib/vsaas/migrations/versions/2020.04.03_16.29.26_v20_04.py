"""v20.04

Revision ID: v20.04
Revises: b58574bc7307
Create Date: 2020-04-03 16:29:26.544654

"""

# revision identifiers, used by Alembic.
revision = 'v20.04'
down_revision = 'b58574bc7307'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
