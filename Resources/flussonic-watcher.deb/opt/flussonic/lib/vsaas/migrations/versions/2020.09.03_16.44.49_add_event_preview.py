"""add_event_preview

Revision ID: 855c5d6c4c38
Revises: 58e696756163
Create Date: 2020-09-03 16:44:49.234165

"""

# revision identifiers, used by Alembic.
revision = '855c5d6c4c38'
down_revision = '58e696756163'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402
from sqlalchemy.dialects import postgresql  # noqa: F402


def upgrade():
  op.add_column('events', sa.Column('preview', sa.LargeBinary(), nullable=True))


def downgrade():
  op.drop_column('events', 'preview')
