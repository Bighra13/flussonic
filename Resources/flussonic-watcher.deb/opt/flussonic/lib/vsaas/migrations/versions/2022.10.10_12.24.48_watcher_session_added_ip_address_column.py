"""watcher_session_added_ip-address_column

Revision ID: a83d339f2ce9
Revises: 837b583b544b
Create Date: 2022-10-10 12:24:48.574233

"""

# revision identifiers, used by Alembic.
revision = 'a83d339f2ce9'
down_revision = '837b583b544b'

from tokenize import String
from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    op.add_column('watcher_sessions', sa.Column('ip', sa.String(), nullable=True))


def downgrade():
    op.drop_column('watcher_sessions', 'ip')
