"""add_organization_settings

Revision ID: 9e3b5aef0ccb
Revises: 7ee6c94eb405
Create Date: 2021-07-29 12:02:29.519498

"""

# revision identifiers, used by Alembic.
revision = '9e3b5aef0ccb'
down_revision = '7ee6c94eb405'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402
from sqlalchemy.dialects import postgresql  # noqa: F402


def upgrade():
  op.add_column(
    'organizations',
    sa.Column(
      'settings',
      postgresql.JSONB(astext_type=sa.Text()), server_default=sa.text("'{}'::jsonb"),
      nullable=False
    )
  )


def downgrade():
  op.drop_column('organizations', 'settings')
