"""faces person_id idx

Revision ID: 054cbf6fd571
Revises: 4abfbe3886ca
Create Date: 2022-02-11 10:34:06.308078

"""

# revision identifiers, used by Alembic.
revision = '054cbf6fd571'
down_revision = '4abfbe3886ca'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    op.create_index('ix_activity_faces_person_id', 'activity_faces', ['person_id'], unique=False)
    pass


def downgrade():
    op.drop_index('ix_activity_faces_person_id', table_name='activity_faces')
    pass
