"""car plates wo number added

Revision ID: 0b3cf8518761
Revises: b20c35b6411f
Create Date: 2021-08-17 15:30:06.389848

"""

# revision identifiers, used by Alembic.
revision = '0b3cf8518761'
down_revision = 'b20c35b6411f'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402
from sqlalchemy.dialects import postgresql  # noqa: F402


def upgrade():
    op.alter_column('license_plates', 'plate_number',
                    existing_type=sa.VARCHAR(),
                    nullable=True)


def downgrade():
    op.alter_column('license_plates', 'plate_number',
                    existing_type=sa.VARCHAR(),
                    nullable=False)
