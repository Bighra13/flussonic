"""v20.07

Revision ID: v20.07
Revises: 9955e21bb2e6
Create Date: 2020-06-30 15:43:41.538445

"""

# revision identifiers, used by Alembic.
revision = 'v20.07'
down_revision = '9955e21bb2e6'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402


def upgrade():
    pass


def downgrade():
    pass
