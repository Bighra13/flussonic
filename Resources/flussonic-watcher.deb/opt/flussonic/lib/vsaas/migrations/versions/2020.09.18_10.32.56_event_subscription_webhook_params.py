"""event_subscription_webhook_params

Revision ID: 1a34d6adb032
Revises: 855c5d6c4c38
Create Date: 2020-09-18 10:32:56.912930

"""

# revision identifiers, used by Alembic.
revision = '1a34d6adb032'
down_revision = '855c5d6c4c38'

from alembic import op  # noqa: F402
import sqlalchemy as sa  # noqa: F402
from sqlalchemy.dialects import postgresql  # noqa: F402


def upgrade():
    op.add_column(
        'event_subscriptions',
        sa.Column(
            'webhook_params',
            postgresql.JSONB(astext_type=sa.Text()),
            server_default=sa.text("'{}'::jsonb"),
            nullable=False
        )
    )


def downgrade():
    op.drop_column('event_subscriptions', 'webhook_params')
