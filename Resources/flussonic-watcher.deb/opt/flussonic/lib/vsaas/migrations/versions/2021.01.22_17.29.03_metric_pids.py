"""metric pids

Revision ID: 7a282dfdf61b
Revises: 6f216269d67c
Create Date: 2021-01-22 17:29:03.898262

"""

# revision identifiers, used by Alembic.
revision = '7a282dfdf61b'
down_revision = '6f216269d67c'

from alembic import op  # noqa: F402
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql  # noqa: F402


def upgrade():
    op.drop_column('watcher_metrics', 'samples')
    op.add_column(
        'watcher_metrics',
        sa.Column('samples', postgresql.ARRAY(postgresql.JSONB()), server_default='{}', nullable=False)
    )


def downgrade():
    op.drop_column('watcher_metrics', 'samples')
    op.add_column(
        'watcher_metrics',
        sa.Column('samples', sa.ARRAY(sa.Text), server_default='{}', nullable=False)
    )
